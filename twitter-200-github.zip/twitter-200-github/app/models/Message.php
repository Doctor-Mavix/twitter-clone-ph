<?php

class Message
{
    public function send()
    {
    }
}
