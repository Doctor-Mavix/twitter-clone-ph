<?php $title = $data->username ?>
<?php  require_once(VIEW_ROOT."/layouts/app.php");?>

    <div  class="twt-p  ">
        
        <?php  require_once(VIEW_ROOT."/layouts/navbar.php");?>
        <div id="tweet-view" data-tweet-id="<?=$data->id?>">
           
            
            
            
        </div>


        
        <?php  require_once(VIEW_ROOT."/layouts/footer.php");?>

    </div>








    
    <?php  require_once(VIEW_ROOT."/layouts/app-foot.php");?>

























