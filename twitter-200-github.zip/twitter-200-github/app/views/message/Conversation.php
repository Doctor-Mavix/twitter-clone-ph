<?php
$receiver = $data;
?>

<div>

    <h1><?= $data->username ?></h1>
    <form method="POST" action="">

        <input placeholder="Entrer votre message" name="message" type="text">

    </form>


</div>