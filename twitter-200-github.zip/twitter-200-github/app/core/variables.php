<?php 



    $controller = new UsersController();

    $controller->get_user();


    $TweetController = new TweetsController();
