<?php 

    require_once("../app/initialize.php");

    new Router();